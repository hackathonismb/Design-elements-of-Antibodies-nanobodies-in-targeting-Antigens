import sys
import glob
#file1= sys.argv[1] # list of the variants file
#fh = open(file1.strip(),"r")
file2= sys.argv[1] # output from the epitope.js having epitopes-paratopes information from PDB
eph = open(file2.strip(),"r")
#z=fh.readline()
import itertools
from itertools import groupby
from collections import OrderedDict

# Processing pdb_epitopes_paratopes file from epitope.js command
import pandas as pd
   
import collections
  
# creating a dataframe from a dictionary 
#df = pd.DataFrame(eph)
  
#print(df)

count=[]
epipara=[]
for line in eph:
    a=line.strip()
    count.append(a)
#print(count)
#print(epipara)




from collections import Counter
mut=Counter(count)
print(mut)

df = pd.DataFrame(epipara)

#print(df)

