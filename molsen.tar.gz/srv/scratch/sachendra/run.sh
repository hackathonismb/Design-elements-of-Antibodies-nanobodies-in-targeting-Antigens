#!/bin/bash
#for f in ./sachendra;
#  do
          #file=`ls $f/OSCC-GB_*".bam"`
          #name=`echo $bamfile | awk -F'.bam' '{print $1}'`

          #cat part.sam | grep -v ^@ | awk 'NR%2==1 {print "@"$1"\n"$10"\n+\n"$11}' > samplename_1.fastq
          #cat part.sam | grep -v ^@ | awk 'NR%2==0 {print "@"$1"\n"$10"\n+\n"$11}' > samplename_2.fastq
#  done;
~

