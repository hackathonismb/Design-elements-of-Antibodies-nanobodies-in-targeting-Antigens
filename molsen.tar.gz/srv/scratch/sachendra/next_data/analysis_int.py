import sys
import glob
#file1= sys.argv[1] # list of the variants file
#fh = open(file1.strip(),"r")
file2= sys.argv[1] # output from the epitope.js having epitopes-paratopes information from PDB
eph = open(file2.strip(),"r")
#z=fh.readline()
import itertools
from itertools import groupby
from collections import OrderedDict

# Processing pdb_epitopes_paratopes file from epitope.js command
import pandas as pd
   
  
# creating a dataframe from a dictionary 
#df = pd.DataFrame(eph)
  
#print(df)

count=[]
epipara=[]
for line in eph:
    print(line)
    line=line.strip().split(",")
    if line[3] == line[4]:
        a=int(line[5])+int(line[6])+int(line[7])+int(line[8])+int(line[9])+int(line[10])
        print("wild"+"="+str(a))
    if line[3] != line[4]:
        b=int(line[5])+int(line[6])+int(line[7])+int(line[8])+int(line[9])+int(line[10])
        print("mutant"+"="+str(b))
        if a == b:
            count.append("no_change"+line[3]+line[2]+line[4])
        if a > b:
            count.append("decrease"+line[3]+line[2]+line[4])
        if a < b:
            count.append("increase" +line[3]+line[2]+line[4])
   # print(line)
#    pdb=line[1].strip().split("_")
#    epipara.append([pdb[0],pdb[1],line[2].strip()])
    #epipara.append(line)
print(count)
#print(epipara)

from collections import Counter
mut=Counter(count)
#print(mut,sep="\n")
df = pd.DataFrame(epipara)

#print(df)


'''
ntd=[]
rbd=[]

for i,data in enumerate(epipara):
    if i == len(epipara)-1:
        a=data[2]
        if int(a)<=303:
            ntd.append([data[1],data[2]])
        if int(a)>303:
             rbd.append([data[1],data[2]])

print(ntd)
print(rbd)

'''
