#!/bin/bash
input="/home/jupyter-sachendra/scratch/sachendra/dat1.txt"
while IFS= read -r line
do
	name=`echo $line`
	pdb_name=`echo $name | awk -F '\t' '{print substr ($NF,1)}'`
	#echo $pdb_name
	node epitope.js $name > ab.txt
	python comm.py > mut.txt
	node interaction.js
done < "$input"

