import sys
import glob
#file1= sys.argv[1] # list of the variants file
#fh = open(file1.strip(),"r")
file2= sys.argv[1] # output from the epitope.js having epitopes-paratopes information from PDB
eph = open(file2.strip(),"r")
#z=fh.readline()
import itertools
from itertools import groupby
from collections import OrderedDict

# Processing pdb_epitopes_paratopes file from epitope.js command

epipara=[]
for line in eph:
    line=line.strip().split(",")
   # print(line)
    pdb=line[1].strip().split("_")
    epipara.append([pdb[0],pdb[1],line[2].strip()])
#print(epipara)

ntd=[]
rbd=[]

for i,data in enumerate(epipara):
    if i == len(epipara)-1:
        a=data[2]
        if int(a)<=303:
            ntd.append([data[0],data[2]])
        if int(a)>303:
             rbd.append([data[0],data[2]])

print(ntd)
print(rbd)
