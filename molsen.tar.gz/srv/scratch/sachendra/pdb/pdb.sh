input="/home/jupyter-sachendra/scratch/sachendra/pdb/pdnm.txt"

j=0 # introduce a variable
while read line; do
    ((j++))
    name=`echo $line`
    pdb_name=`echo $name | awk -F ' ' '{print $1}'`
    echo $name # input for the epitope.js command for identifying epitopes-paratopes information from a PDB
   
    # 1. Identifying  epitopes-paratopes infromation from a PDB 
    # usage synatax: node epitope.js [PDB ID] [master chain ID] [binding partner chain ID] > [output_epitope_paratope.txt]
    # Example: node epitope.js 7CM4    A   H > 7CM4, 7CM4_A, 403, R, Spike glycoprotein, 7CM4_H, 56, D, IgG heavy chain
    #node epitope.js $name > $pdb_name"_"${j}"_epitopes_paratopes_heavy.txt"

    # 2. Matching of the mutant postion from mutant.txt and pdb_epitope_paratope.txt for comparing wild type and mutant type > [output_pdb_epitopes.txt]
    # usage syntax: python3 molecularSentry_match_mutant_position.py variants.txt pdb_epitopes_paratopes.txt
    # Example Matching of the third column of pdb_epitope_paratope.txt (here, 403) with  mutant.txt (one mutant perline, here, R403H,so on) containing residue number  say (403) and one letter mutant (H)
    
    python3 pdb.py $name > pdb_info.txt
done < "$input"
