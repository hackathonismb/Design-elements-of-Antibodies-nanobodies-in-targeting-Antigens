import sys
import glob
import re
#file1= sys.argv[1] # list of the variants file
#fh = open(file1.strip(),"r")

from Bio.PDB import *
parser = PDBParser(QUIET=True)
#parser = PDBParser(PERMISSIVE=1)
file2= sys.argv[1] # output from the epitope.js having epitopes-paratopes information from PDB
eph = open(file2.strip(),"r")
#structure=parser.get_structure("example", '6ZER.pdb')
#model = structure.get_models()
#models = list(model)
#chains = list(models[0].get_chains())
#print(structure.header["compound"])
#print(chains)
pdb_sars=[]
for pdb in eph:
    #fname = pdb.split(pdb=",")
    a=pdb.strip().split(",")
    for j in a:
        b=j.strip().split(",")
        #print(b)
        pdb_sars.append(b)
#print(pdb_sars)
flat_list = [item for sublist in pdb_sars for item in sublist]
string=".pdb"
output = ["{}{}".format(i,string) for i in flat_list]

for i in output:
    j=i.strip().split(".")
    #print(i)
    structure=parser.get_structure("example", i)
    model = structure.get_models()
    models = list(model)
    #chains = list(models[0].get_chains())
#print(structure.header["compound"])
    #print(chains,i)
    #print(i,structure.header["compound"]["1"]["chain"][0], structure.header["compound"]["2"]["chain"][0], structure.header["compound"]["3"]["chain"][0])
    #if re.match("^s|^r",structure.header["compound"]["1"]["molecule"]):
        #print(structure.header["compound"]["1"]["chain"][0].upper())
    #if re.match("^s|^r",structure.header["compound"]["1"]["molecule"]):
    print(i,structure.header["compound"])
    print(j[0],structure.header["compound"]["1"]["chain"][0].upper(), structure.header["compound"]["2"]["chain"][0].upper(), structure.header["compound"]["3"]["chain"][0].upper())
