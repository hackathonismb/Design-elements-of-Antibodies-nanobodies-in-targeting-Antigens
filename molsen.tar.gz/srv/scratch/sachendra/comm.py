import sys
import glob
file1= sys.argv[1]
fh = open(file1.strip(),"r")
file2= sys.argv[2]
eph = open(file2.strip(),"r")

#fh=open('/home/jupyter-sachendra/scratch/sachendra/mutant.txt', "r")
#eph=open('/home/jupyter-sachendra/scratch/sachendra/ab.txt', "r")
z=fh.readline()
#print(z)

from itertools import groupby

def split_text(s):
    for k, g in groupby(s, str.isalpha):
        yield ''.join(g)

key=[]
mut=[]
for line in fh:
    line=line.strip()
    key.append(line)
    mut.append(list(split_text(line)))
#print(key)
#print(mut)



epipara=[]
for line in eph:
    line=line.strip().split(",")
   # print(line)
    pdb=line[1].strip().split("_")
    epipara.append([pdb[0],pdb[1],line[2].strip()])
#print(epipara)

import itertools
k=[]
intract_wild=[]
intract_mut=[]
for i in mut:
    a=int(i[1])
    #print(a)
    for j in epipara:
        b=int(j[2])
        #print(b)
        if a==b:
            intract_mut.append([j+list(i[2])])
            intract_wild.append([j+list(i[0])])
#print(intract_wild)
#print(intract_mut)
int_wld=(list(itertools.chain.from_iterable(intract_wild)))
int_mut=(list(itertools.chain.from_iterable(intract_mut)))

#print(int_mut)
from collections import OrderedDict
int_mutate=(list(map(list, OrderedDict.fromkeys(map(tuple, int_mut)).keys())))
int_wild=(list(map(list, OrderedDict.fromkeys(map(tuple, int_wld)).keys())))

'''
with open('mut.tab','w') as f:
    for row in int_mutate:
        for x in row:
            f.write(str(x) + '\t')
        f.write('\n')

with open('wild.tab','w') as f:
    for row in int_wild:
        for x in row:
            f.write(str(x) + '\t')
        f.write('\n')

'''
def listToString(s):

    # initialize an empty string
    str1 = " "

    # return string
    return (str1.join(s))

#for i in int_wild:
    #print((listToString(i)), sep="\t")
    #for j in int_mutate:
        #print((listToString(i)), sep="\t")
        #print((listToString(j)), sep="\t")
for f, b in zip(int_wild, int_mutate):
    print((listToString(f)),(listToString(b)), sep="\n")
#print(int_wild)
#int_wild=(list(itertools.chain.from_iterable(int_wld)))
#int_mutate=(list(itertools.chain.from_iterable(int_mutate)))
#print(int_mutate, sep="\n")
# Function to convert
'''
def listToString(s):

    # initialize an empty string
    str1 = " "

    # return string
    return (str1.join(s))
'''

# Driver code
#s = ['Geeks', 'for', 'Geeks']
#w=(listToString(int_wild))
#w=set(w)
#m=(listToString(int_mutate))
#m=set(m)

#print(w)
#print(m)


#import re
#print ({i:j  for j in key2 for i in epipara if re.match(i,j)})
#print ({j:i for i,j in zip(key2,epipara) if re.match(j,i)})
