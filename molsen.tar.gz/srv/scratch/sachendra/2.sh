#!/bin/bash
input="/home/jupyter-sachendra/scratch/sachendra/nano_rbd.txt"
mut="/home/jupyter-sachendra/scratch/sachendra/voc.txt"
#intract="/home/jupyter-sachendra/scratch/sachendra/$pdb_name"_"${j}_wild.txt"
j=0 # introduce a variable
while read line; do
    ((j++))
    name=`echo $line`
    pdb_name=`echo $name | awk -F ' ' '{print $1}'`
    echo $name
    node epitope.js $name > $pdb_name"_"${j}"_N.txt"
    python comm.py voc.txt $pdb_name"_"${j}"_N.txt" > $pdb_name"_"${j}"_epitope_interaction_N.txt"
    #node interaction.js
    #output=$(python comm.py mutant.txt $pdb_name"_"${j}.txt 2>&1) 
    #name2=`echo $output`
    #echo $name2
    intract="/home/jupyter-sachendra/scratch/sachendra/$pdb_name"_"${j}_epitope_interaction_N.txt"
    k=0 # introduce a variable
    while read line; do
    	((k++))
    	name2=`echo $line`
    	#echo $name2
	pdb_name2=`echo $name | awk -F ' ' '{print $1}'`
    	#echo $pdb_name2
	node interaction2.js $name2 >>$pdb_name"_"${j}"_N.txt" 
    done < "$intract"	

    #echo "${j} ${line}" > line_no_${j}.txt # Saving it to a new file
    #wc -l line_no_${j}.txt > second_command_output_${j}.txt # Open the file saved above and use it as input
done < "$input"

